<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package coopers-front
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<!-- Meta tags Obrigatórias -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
   
    <title>Coopers - Site para teste Front-End</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,400;0,600;0,700;0,900;1,900&family=Poppins:ital,wght@0,400;0,600;1,400&display=swap" rel="stylesheet">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div class="topo container-fluid">
        
        <div class="topo-centro container"> 
            <h1>
                <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/imgs/logo.png" alt="Logo Coopers"></a>   
            </h1>
        </div>

        <?php get_template_part('inc/fullbanner');?>

        <div class="container">
            <div class="row">
                <div class="icon-scroll col-md-12 text-center">
                    <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/imgs/icon-scroll.png" alt="icon-scroll"></a>
                </div>
            </div>
        </div>

    </div>

</header><!-- #masthead -->
