<?php 
$args = array(
    'post_type' => 'to_do_list',
    'post_status' => 'publish',
    'posts_per_page' => 1 
);
$the_query = new WP_Query( $args );
// The Loop
// var_dump($the_query);
if ( $the_query->have_posts() ):
  
?>

<div class="bg-list container-fluid pdl pdr">
    <div class="container">

    <?php  while ( $the_query->have_posts() ): 
        $the_query->the_post();?>

        <div class="row">
            <div class="to-do col-md-12 text-center">
                <div class="col-md-4 mx-auto">
                    <h2><?php the_field('to_do_list'); ?></h2>
                </div>
                
                <div class="col-md-7 mx-auto">
                    <p><?php the_field('descricao_da_lista'); ?></p>
                </div>
            </div>
        </div>

        <?php  endwhile; ?>

    </div>
</div>

<?php else: ?>
<?php endif;?> 
<?php 
    wp_reset_query(); 
?>