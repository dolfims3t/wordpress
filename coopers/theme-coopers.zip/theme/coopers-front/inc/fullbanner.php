<?php //query_posts('showposts=10&fullbanner&offset=0&order=DESC');
$args = array(
    'post_type' => 'fullbanner',
    'post_status' => 'publish',
    'posts_per_page' => 5 
);
$the_query = new WP_Query( $args );
// The Loop
// var_dump($the_query);
if ( $the_query->have_posts() ):
  
?>
<div class="slides container">
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">

        <?php  while ( $the_query->have_posts() ): 
            $the_query->the_post();?>
        
        <div class="carousel-item active">
            <div class="row">

                
                <div class="col-md-6">
                    <p>
                        <span class="txt-sld-1"><?php the_field('titulo_'); ?></span><br><span class="txt-sld-2"><?php the_field('subtitulo'); ?></span><br>
                        <span class="txt-sld-3"><?php the_field('descricao'); ?></span>
                    </p>
                    <div class="btn-meet col-md-6">
                        <a href="<?php the_field('botao_de_link'); ?>" target="_blank">Meet the To-do list</a>
                    </div>        
                </div>
                <div class="col-md-6">
                    <div class="d-block">
                        <?php the_post_thumbnail('full'); ?>
                    </div>
                </div>
            </div>
        </div>
        
        <?php  endwhile; ?>
            
        </div>
    
    </div>
</div>

<?php else: ?>
<?php endif;?> 
<?php 
    wp_reset_query(); 
?>