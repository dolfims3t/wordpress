
<?php 
$args = array(
    'post_type' => 'good_things',
    'post_status' => 'publish',
    'posts_per_page' => 3 
);
$the_query = new WP_Query( $args );
// The Loop
// var_dump($the_query);
if ( $the_query->have_posts() ):
  
?>

<div class="area-good container">
    <div class="row">
        <div class="col-md-12">
            <h2>good things</h2>
        </div>
    </div>
    <div class="destaques row">

        <?php  while ( $the_query->have_posts() ): 
        $the_query->the_post();?>    

            <div class="col-md-4 col-sm-12 box-dest pdl pdr mr-3">
                <div class="img-fluid"><?php the_post_thumbnail('full'); ?></div>
                <span class="seta"></span>
                <h3><span><?php the_field('tipo'); ?></span></h3>
                <p><a href="#"><?php the_field('descricao'); ?></a></p>
                <a href="<?php the_field('leia_mais'); ?>" target="_blank" class="btn-read">read more</a>
            </div>

        <?php  endwhile; ?>     

    </div>
</div>

<?php else: ?>
<?php endif;?> 
<?php 
    wp_reset_query(); 
?>