<?php 
$args = array(
    'post_type' => 'planos',
    'post_status' => 'publish',
    'posts_per_page' => 3 
);
$the_query = new WP_Query( $args );
// The Loop
// var_dump($the_query);
if ( $the_query->have_posts() ):
  
?>

<div class="planos container-fluid pdl pdr">
    <div class="container">
        <div class="row">
            
            <?php  while ( $the_query->have_posts() ): 
            $the_query->the_post();?>

                <div class="detalhes col-md-4 mx-auto">
                    
                    <h2><?php the_field('valor_do_plano_mensal'); ?></h2>
                    <h3><?php the_field('tipo_de_plano'); ?></h3>
                    <h4><?php the_field('descricao_do_plano'); ?></h4>

                    <ul>
                        <li><img src="<?php echo get_template_directory_uri(); ?>/imgs/check-ok.png">Create to-do lists</li>
                        <li><img src="<?php echo get_template_directory_uri(); ?>/imgs/check-ok.png">Share lists WhatsApp</li>
                        <li><img src="<?php echo get_template_directory_uri(); ?>/imgs/vector.png">Offline mode</li>
                        <li><img src="<?php echo get_template_directory_uri(); ?>/imgs/vector.png">Invite coladorators</li>
                        <li><img src="<?php echo get_template_directory_uri(); ?>/imgs/vector.png">Dark modde</li>
                    </ul>

                    <div class="btn-touch col-md-10 mx-auto">
                        <a href="<?php the_field('get_in_touch'); ?>" target="_blank">get in touch</a>
                    </div> 

                </div>

            <?php  endwhile; ?>  

        </div>
    </div>         
</div>

<?php else: ?>
<?php endif;?> 
<?php 
    wp_reset_query(); 
?>